package com.coupleconn.webpages;

public class crap {
	public static void main(String[] args){
		Integer g = 0;
		if (g == null){
			System.out.println("qqq");
		}
		if (g.equals(0)){
			System.out.println("asfasd");
		}
	}
}
