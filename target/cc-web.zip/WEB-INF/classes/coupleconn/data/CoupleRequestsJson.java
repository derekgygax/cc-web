package com.coupleconn.data;

import java.util.ArrayList;
import java.util.HashMap;

import com.coupleconn.util.Api;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

public class CoupleRequestsJson {
	public ArrayList<Object> to;
	public ArrayList<Object> from;
	

}
