package com.coupleconn.data;

public class ChatRoomInfo {
	public String roomId;
	public String homePartnerId;
	public String matchHigherName;
	public String matchLowerName;
}
