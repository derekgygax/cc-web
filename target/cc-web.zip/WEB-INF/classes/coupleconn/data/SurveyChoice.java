package com.coupleconn.data;

public class SurveyChoice {
	public String questionID;
	public String text;
	public int value;
	public int importance;
}
