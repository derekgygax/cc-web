package com.coupleconn.data;

public class SearchParamViews {
	public static class Base {
		
	}
	
	public static class Range extends Base {
		
	}
	
	public static class Enumeration extends Base {
		
	}
	
	public static class Multiselect extends Enumeration {
		
	}
	
	public static class Singleselect extends Enumeration {
		
	}

}
