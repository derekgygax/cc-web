package com.coupleconn.data;

import java.util.ArrayList;
import java.util.HashMap;

public class SurveyOverview {
	public ArrayList<SurveyGroup> groups;
	public String nextGroup;
	
	public SurveyOverview() {
		groups = new ArrayList<SurveyGroup>();
	}
	

}
