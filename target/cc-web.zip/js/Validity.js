let Validity = {
	isZipcodeValid: function(zipcode){
		return CommonFunctions.isNumber(numChildren);
	},
	
	isAgeValid: function(age){
		return CommonFunctions.isNumber(numChildren);
	},
	
	isNumChildrenValid: function(numChildren){
		return CommonFunctions.isNumber(numChildren);
	},
	
		
};